import React from 'react';
import '../styles/style.css';
import Logo from '../styles/oliomart.png';



const Main = () => {
    return (
        <>
        
<div className='index'>

            <img src={Logo} className='logo'/>
            {/* <span>adshsadb</span> */}
            <p><span className='line2-1'>MAXIMUM REACH FOR</span><span className='line2-2' > HOMEMADE PRODUCTS</span></p>
            <p className='disc'>Consectetur tempor consequat elit ea id adipisicing aute excepteur reprehenderit est dolore nulla.
            Cillum proident cupidatat in velit nisi et commodo amet aliqua velit. Sunt et sint commodo eiusmod quis laborum. 
            Consectetur tempor consequat elit ea id adipisicing aute excepteur reprehenderit est dolore nulla. 
            Cillum proident cupidatat in velit nisi et commodo amet aliqua velit. Sunt et sint commodo eiusmod quis laborum.</p>
            <div className='buttons'> 
                <button>Skip</button>
                <button>Login</button>
            </div>        
        </div>
        </>
        
    )
}

export default Main
