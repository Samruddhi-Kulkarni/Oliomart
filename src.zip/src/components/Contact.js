import React from 'react'

const Contact = () => {
    return (
        <div className='cntct'>
            <p>This is the Contact Page</p>
        </div>
    )
}

export default Contact
