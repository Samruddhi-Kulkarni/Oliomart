import React from "react";
import { BrowserRouter } from "react-router-dom";
import { Link } from "react-router-dom";
import AccountImg from '../styles/TestAccount.png'

const Navbar = () => {
  return (
    <div>
      <div className="menu_links">
        <ul className="links">
          <nav>
            <li >
              <Link to='/'  exact >Home</Link>
            </li>
            <li>
              <Link to='/tutorial' > Tutorial </Link>
            </li>
            <li>
              <Link to='/about' > About </Link>
            </li>
            <li>
              <Link to='/contact' > Contact </Link>
            </li>
          </nav>
        </ul>
        <button className="sell">Sell on Olio</button>
        <img src={AccountImg} alt='AccountProfile' className="demoPro"/>
      </div>
    </div>
  );
};

export default Navbar;
