import React from 'react'

const About = () => {
    return (
        <div className='abt'>
            <p>This is the about Page</p>
        </div>
    )
}

export default About
