import React from 'react'

const Tutorial = () => {
    return (
        <div className='tut'>
            <p>Hi I am Tutorial Page</p>        
        </div>
    )
}

export default Tutorial