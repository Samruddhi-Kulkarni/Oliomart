import React from 'react'
import Main from './components/Main'
import Navbar from './components/Navbar'
import { Route, Routes} from 'react-router-dom'
import Tutorial from './components/Tutorial'
import About from './components/About'
import Contact from './components/Contact'

const App = () => {
  return (
    <>
      <Navbar/>
      <Routes>
        <Route path='/' element={<Main/>}/>
        <Route path='/tutorial' element={<Tutorial/>}/>
        <Route path='/navbar' element={<Navbar/>}/>
        <Route path='/about' element={<About/>}/>
        <Route path='/contact' element={<Contact/>}/>
      </Routes>
    </>
    
    // <div className='main_frame'>
    //   <Main/>
    // </div>
  )
}

export default App